# Calmify 🔔
সব নোটিফিকেশন এক ইনবক্সে — Important / Saved / Unread ট্যাব, অ্যাপ অনুযায়ী গ্রুপ, Gmail লগইন। ডাটা শুধু ফোনে (Room)।

## চালানোর ধাপ
1. Android Studio (Koala+) দিয়ে ফোল্ডারটি Open করুন → Gradle Sync।
2. **Gmail লগইনের জন্য** [Google Cloud Console](https://console.cloud.google.com) → APIs & Services → Credentials:
   - OAuth consent screen বানান।
   - **Android** client তৈরি করুন (package `com.likhon.calmify` + আপনার debug SHA-1; `./gradlew signingReport`)।
   - **Web application** client তৈরি করুন → এর Client ID কপি করুন।
3. `app/build.gradle.kts`-এ `WEB_CLIENT_ID` বদলে সেই Web Client ID বসান।
4. ফোনে Run করুন → লগইন → "অনুমতি দিন" চেপে Calmify-এ Notification access অন করুন।
