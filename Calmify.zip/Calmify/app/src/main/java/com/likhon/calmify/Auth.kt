package com.likhon.calmify

import android.app.Activity
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

object Auth {
    /** Google অ্যাকাউন্ট দিয়ে সাইন-ইন করে Gmail ঠিকানা ফেরত দেয় */
    suspend fun signIn(activity: Activity): String {
        val option = GetSignInWithGoogleOption.Builder(BuildConfig.WEB_CLIENT_ID).build()
        val req = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val res = CredentialManager.create(activity).getCredential(activity, req)
        return GoogleIdTokenCredential.createFrom(res.credential.data).id
    }
}
