package com.likhon.calmify

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.*

class HubListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun setConnected(v: Boolean) =
        getSharedPreferences("hub", MODE_PRIVATE).edit().putBoolean("connected", v).apply()

    override fun onListenerConnected() { setConnected(true) }

    override fun onListenerDisconnected() {
        setConnected(false)
        try { requestRebind(ComponentName(this, HubListener::class.java)) } catch (_: Exception) {}
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing || !Prefs.isAllowed(this, sbn.packageName)) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val x = n.extras
        val title = (x.getCharSequence(Notification.EXTRA_TITLE) ?: x.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE))?.toString().orEmpty()
        val text = (x.getCharSequence(Notification.EXTRA_TEXT)
            ?: x.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: x.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.lastOrNull())?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName.substringAfterLast('.') }
        scope.launch {
            try { Db.get(this@HubListener).dao().insert(Notif(pkg = sbn.packageName, appName = app, title = title, text = text, time = sbn.postTime)) }
            catch (_: Exception) {}
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
