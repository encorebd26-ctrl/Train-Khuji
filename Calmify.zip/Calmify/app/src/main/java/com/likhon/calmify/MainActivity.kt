package com.likhon.calmify

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("hub", MODE_PRIVATE)
        setContent {
            HubTheme {
                var email by remember { mutableStateOf(prefs.getString("email", null)) }
                var error by remember { mutableStateOf<String?>(null) }
                val scope = rememberCoroutineScope()
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val e = email
                    if (e == null) LoginScreen(error) {
                        scope.launch {
                            try {
                                val got = Auth.signIn(this@MainActivity)
                                prefs.edit().putString("email", got).apply(); email = got; error = null
                            } catch (t: Exception) { error = "লগইন হয়নি: ${t.message}" }
                        }
                    } else InboxScreen(e) { prefs.edit().remove("email").apply(); email = null }
                }
            }
        }
    }
}
