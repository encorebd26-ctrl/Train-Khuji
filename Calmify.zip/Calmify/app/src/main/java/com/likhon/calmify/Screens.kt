package com.likhon.calmify

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
private fun Title(key: String, sub: String? = null) {
    Column {
        Text(tr(key), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        sub?.let { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun Section(titleKey: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(tr(titleKey), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 4.dp))
        Card(shape = RoundedCornerShape(24.dp), elevation = CardDefaults.cardElevation(2.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
        }
    }
}

@Composable
private fun Choice(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (v, label) -> FilterChip(selected = selected == v, onClick = { onSelect(v) }, shape = RoundedCornerShape(18.dp), label = { Text(label) }) }
    }
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    val apps = remember {
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != ctx.packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
    }
    var allowAll by remember { mutableStateOf(Prefs.allowAll(ctx)) }
    var allowed by remember { mutableStateOf(Prefs.allowed(ctx)) }
    var q by remember { mutableStateOf("") }
    val shown = apps.filter { q.isBlank() || it.second.contains(q, true) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Title("apps", tr("apps_sub")) }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("all_apps"), fontWeight = FontWeight.SemiBold)
                        Text(tr("all_apps_sub"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = allowAll, onCheckedChange = { allowAll = it; Prefs.setAllowAll(ctx, it) })
                }
            }
        }
        if (!allowAll) {
            item {
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp),
                    placeholder = { Text(tr("search_apps")) }, leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = { if (q.isNotEmpty()) IconButton(onClick = { q = "" }) { Icon(Icons.Rounded.Close, null) } },
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = MaterialTheme.colorScheme.outline, unfocusedContainerColor = MaterialTheme.colorScheme.surface, focusedContainerColor = MaterialTheme.colorScheme.surface)
                )
            }
            item { Text("${allowed.size} ${tr("selected")}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary) }
            items(shown, key = { it.first }) { (pkg, label) ->
                val icon = remember(pkg) { runCatching { pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull() }
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (icon != null) Image(icon, null, Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)))
                        else Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer))
                        Spacer(Modifier.width(12.dp))
                        Text(label, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Switch(checked = pkg in allowed, onCheckedChange = { on ->
                            Prefs.setAllowed(ctx, pkg, on); allowed = if (on) allowed + pkg else allowed - pkg
                        })
                    }
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: Int, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("$value", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
            Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun BarRow(label: String, count: Int, max: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(.38f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
        Box(Modifier.weight(.5f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
            Box(Modifier.fillMaxWidth(count.toFloat() / max).fillMaxHeight().clip(RoundedCornerShape(5.dp)).background(MaterialTheme.colorScheme.primary))
        }
        Text("$count", Modifier.weight(.12f), textAlign = androidx.compose.ui.text.style.TextAlign.End, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun InsightsScreen(items: List<Notif>) {
    val dayMs = 86_400_000L
    val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val days = (6 downTo 0).map { i -> val s = today - i * dayMs; s to items.count { it.time >= s && it.time < s + dayMs } }
    val maxDay = (days.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    val topApps = items.groupBy { it.appName }.map { it.key to it.value.size }.sortedByDescending { it.second }.take(5)
    val cats = items.groupBy { categoryOf(it.pkg) }.map { it.key to it.value.size }.sortedByDescending { it.second }
    val fmt = SimpleDateFormat("EEE", Locale.getDefault())
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Title("insights") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Stat(tr("total"), items.size, Modifier.weight(1f)); Stat(tr("unread"), items.count { !it.read }, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Stat(tr("important"), items.count { it.important }, Modifier.weight(1f)); Stat(tr("saved"), items.count { it.saved }, Modifier.weight(1f))
                }
            }
        }
        item {
            Section("last7") {
                Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    days.forEach { (s, n) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Text("$n", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            Box(Modifier.width(28.dp).height((90f * n / maxDay).dp.coerceAtLeast(4.dp)).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primary))
                            Spacer(Modifier.height(4.dp))
                            Text(fmt.format(Date(s)), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item {
            Section("top_apps") {
                if (topApps.isEmpty()) Text(tr("no_data"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                topApps.forEach { (name, n) -> BarRow(name, n, topApps.first().second) }
            }
        }
        item {
            Section("by_cat") {
                if (cats.isEmpty()) Text(tr("no_data"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                cats.forEach { (k, n) -> BarRow(tr(k), n, cats.first().second) }
            }
        }
    }
}

@Composable
fun SettingsScreen(email: String, theme: String, onTheme: (String) -> Unit, lang: String, onLang: (String) -> Unit, onClear: () -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Title("settings") }
        item {
            Section("appearance") {
                Text(tr("theme"), fontWeight = FontWeight.SemiBold)
                Choice(listOf("system" to tr("system"), "light" to tr("light"), "dark" to tr("dark")), theme, onTheme)
                Text(tr("language"), fontWeight = FontWeight.SemiBold)
                Choice(listOf("en" to "English", "bn" to "বাংলা"), lang, onLang)
            }
        }
        item {
            Section("access") {
                Text(if (granted) "● ${tr("active")}" else "○ ${tr("inactive")}", color = if (granted) androidx.compose.ui.graphics.Color(0xFF10B981) else MaterialTheme.colorScheme.error)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text(tr("access")) }
                    OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))) }) { Text(tr("battery")) }
                }
            }
        }
        item { Section("data") { OutlinedButton(onClick = { confirm = true }) { Text(tr("clear_unsaved")) } } }
        item {
            Section("account") {
                Text(email)
                OutlinedButton(onClick = onSignOut) { Text(tr("sign_out")) }
                Text("${tr("version")} 1.1 · Calmify", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, text = { Text(tr("clear_confirm")) },
        confirmButton = { TextButton(onClick = { onClear(); confirm = false }) { Text(tr("delete")) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text(tr("cancel")) } }
    )
}
