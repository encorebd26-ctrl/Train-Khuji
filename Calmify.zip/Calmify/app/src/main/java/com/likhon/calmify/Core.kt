package com.likhon.calmify

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("hub", Context.MODE_PRIVATE)
    fun theme(c: Context) = sp(c).getString("theme", "system") ?: "system"
    fun setTheme(c: Context, v: String) = sp(c).edit().putString("theme", v).apply()
    fun lang(c: Context) = sp(c).getString("lang", "en") ?: "en"
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()
    fun allowAll(c: Context) = sp(c).getBoolean("allowAll", true)
    fun setAllowAll(c: Context, v: Boolean) = sp(c).edit().putBoolean("allowAll", v).apply()
    fun allowed(c: Context): Set<String> = sp(c).getStringSet("allowed", emptySet())?.toSet() ?: emptySet()
    fun setAllowed(c: Context, pkg: String, on: Boolean) {
        val s = allowed(c).toMutableSet(); if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("allowed", s).apply()
    }
    fun isAllowed(c: Context, pkg: String) = allowAll(c) || pkg in allowed(c)
}

fun categoryOf(pkg: String): String {
    val p = pkg.lowercase()
    fun has(vararg k: String) = k.any { p.contains(it) }
    return when {
        has("whatsapp", "orca", "mlite", "telegram", "signal", "viber", "imo", "mms", "messaging", "sms") -> "c_messages"
        has("facebook", "instagram", "twitter", "linkedin", "snapchat", "tiktok", "reddit", "pinterest", "threads") -> "c_social"
        has("android.gm", "outlook", "mail", "proton") -> "c_email"
        has("daraz", "amazon", "aliexpress", "shopee", "temu", "shein", "pickaboo", "chaldal", "foodpanda", "evaly", "shop") -> "c_shopping"
        has("bkash", "nagad", "rocket", "upay", "bank", "paypal", "wallet", "pay") -> "c_finance"
        else -> "c_other"
    }
}

val LocalT = staticCompositionLocalOf<(String) -> String> { { it } }
@Composable fun tr(k: String): String = LocalT.current(k)
fun translator(lang: String): (String) -> String {
    val m = if (lang == "bn") BN else EN
    return { k -> m[k] ?: EN[k] ?: k }
}

private val EN = mapOf(
    "tagline" to "All your notifications, one calm place", "signin" to "Continue with Google", "login_error" to "Sign-in failed",
    "privacy" to "Your data stays on your phone", "inbox" to "Inbox", "apps" to "Apps", "insights" to "Insights", "settings" to "Settings",
    "all" to "All", "unread" to "Unread", "important" to "Important", "saved" to "Saved", "search" to "Search notifications",
    "nothing" to "Nothing here yet", "empty_hint" to "New notifications from your selected apps will show up here.",
    "grant_title" to "Allow notification access", "grant_body" to "Calmify needs access to collect notifications from your other apps.",
    "grant_btn" to "Grant access", "connected" to "Connected · collecting notifications", "not_connected" to "Service is not running",
    "fix_btn" to "Restart", "battery" to "Battery", "open" to "Open", "mark_read" to "Mark all as read", "notifications" to "notifications",
    "c_social" to "Social", "c_messages" to "Messages", "c_email" to "Email", "c_shopping" to "Shopping", "c_finance" to "Finance", "c_other" to "Other",
    "total" to "Total", "top_apps" to "Top apps", "last7" to "Last 7 days", "by_cat" to "By category", "no_data" to "No data yet",
    "all_apps" to "Collect from all apps", "all_apps_sub" to "Turn off to pick specific apps", "search_apps" to "Search apps", "selected" to "selected",
    "apps_sub" to "Choose which apps Calmify collects notifications from",
    "appearance" to "Appearance", "theme" to "Theme", "system" to "System", "light" to "Light", "dark" to "Dark", "language" to "Language",
    "access" to "Notification access", "account" to "Account", "sign_out" to "Sign out", "data" to "Data",
    "clear_unsaved" to "Clear all except saved", "clear_confirm" to "Delete every notification except the saved ones?",
    "cancel" to "Cancel", "delete" to "Delete", "version" to "Version", "active" to "Active", "inactive" to "Not granted"
)

private val BN = mapOf(
    "tagline" to "সব নোটিফিকেশন, এক শান্ত জায়গায়", "signin" to "Google দিয়ে চালিয়ে যান", "login_error" to "লগইন হয়নি",
    "privacy" to "আপনার ডাটা শুধু ফোনেই থাকে", "inbox" to "ইনবক্স", "apps" to "অ্যাপ", "insights" to "পরিসংখ্যান", "settings" to "সেটিংস",
    "all" to "সব", "unread" to "অপঠিত", "important" to "গুরুত্বপূর্ণ", "saved" to "সেভ করা", "search" to "নোটিফিকেশন খুঁজুন",
    "nothing" to "এখনও কিছু নেই", "empty_hint" to "আপনার বাছাই করা অ্যাপের নতুন নোটিফিকেশন এখানে জমা হবে।",
    "grant_title" to "নোটিফিকেশন অ্যাক্সেস দিন", "grant_body" to "অন্য অ্যাপের নোটিফিকেশন জমা করতে Calmify-র অনুমতি লাগবে।",
    "grant_btn" to "অনুমতি দিন", "connected" to "সংযুক্ত · নোটিফিকেশন জমা হচ্ছে", "not_connected" to "সার্ভিস চালু নেই",
    "fix_btn" to "পুনরায় চালু", "battery" to "ব্যাটারি", "open" to "খুলুন", "mark_read" to "সব পঠিত করুন", "notifications" to "নোটিফিকেশন",
    "c_social" to "সোশ্যাল", "c_messages" to "মেসেজ", "c_email" to "ইমেইল", "c_shopping" to "শপিং", "c_finance" to "আর্থিক", "c_other" to "অন্যান্য",
    "total" to "মোট", "top_apps" to "সেরা অ্যাপ", "last7" to "গত ৭ দিন", "by_cat" to "ক্যাটাগরি অনুযায়ী", "no_data" to "এখনও তথ্য নেই",
    "all_apps" to "সব অ্যাপ থেকে জমা করুন", "all_apps_sub" to "বন্ধ করলে নির্দিষ্ট অ্যাপ বাছতে পারবেন", "search_apps" to "অ্যাপ খুঁজুন", "selected" to "টি বাছাই",
    "apps_sub" to "কোন অ্যাপের নোটিফিকেশন জমা হবে তা বাছুন",
    "appearance" to "চেহারা", "theme" to "থিম", "system" to "সিস্টেম", "light" to "লাইট", "dark" to "ডার্ক", "language" to "ভাষা",
    "access" to "নোটিফিকেশন অ্যাক্সেস", "account" to "অ্যাকাউন্ট", "sign_out" to "সাইন আউট", "data" to "ডাটা",
    "clear_unsaved" to "সেভ করা ছাড়া সব মুছুন", "clear_confirm" to "সেভ করা ছাড়া সব নোটিফিকেশন মুছে ফেলবেন?",
    "cancel" to "বাতিল", "delete" to "মুছুন", "version" to "ভার্সন", "active" to "চালু", "inactive" to "অনুমতি নেই"
)
