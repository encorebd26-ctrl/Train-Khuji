package com.likhon.calmify

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class Notif(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pkg: String, val appName: String, val title: String, val text: String,
    val time: Long, val read: Boolean = false, val important: Boolean = false, val saved: Boolean = false
)

@Dao
interface NotifDao {
    @Query("SELECT * FROM Notif ORDER BY time DESC") fun all(): Flow<List<Notif>>
    @Insert suspend fun insert(n: Notif)
    @Update suspend fun update(n: Notif)
    @Delete suspend fun delete(n: Notif)
}

@Database(entities = [Notif::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): NotifDao
    companion object {
        @Volatile private var i: Db? = null
        fun get(c: Context): Db = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "hub.db").build().also { i = it }
        }
    }
}
