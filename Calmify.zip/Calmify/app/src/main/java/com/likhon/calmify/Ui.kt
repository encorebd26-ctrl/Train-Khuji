package com.likhon.calmify

import android.content.Intent
import android.provider.Settings
import android.text.format.DateUtils
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.launch
import kotlin.math.abs

private val Blue = Color(0xFF2563EB)
private val palette = listOf(Blue, Color(0xFFE11D48), Color(0xFF059669), Color(0xFFD97706), Color(0xFF7C3AED), Color(0xFF0891B2))

@Composable
fun HubTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme())
        darkColorScheme(primary = Color(0xFF7AA2FF), background = Color(0xFF0F1420), surface = Color(0xFF1A2030))
    else lightColorScheme(primary = Blue, background = Color(0xFFF2F5FB), surface = Color.White)
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun LoginScreen(error: String?, onSignIn: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1E40AF), Color(0xFF2563EB), Color(0xFF60A5FA)))).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(96.dp).clip(RoundedCornerShape(32.dp)).background(Color.White.copy(alpha = .2f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.NotificationsActive, null, tint = Color.White, modifier = Modifier.size(52.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Calmify", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Text("সব নোটিফিকেশন, এক জায়গায়", color = Color.White.copy(alpha = .85f), fontSize = 16.sp)
        Spacer(Modifier.height(48.dp))
        Button(
            onClick = onSignIn, shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Icon(Icons.Rounded.Email, null, tint = Color(0xFFEA4335)); Spacer(Modifier.width(10.dp))
            Text("Gmail দিয়ে লগইন করুন", fontWeight = FontWeight.SemiBold)
        }
        error?.let { Spacer(Modifier.height(16.dp)); Text(it, color = Color(0xFFFFE4E6), fontSize = 13.sp) }
        Spacer(Modifier.height(24.dp))
        Text("আপনার ডাটা শুধু ফোনেই থাকে 🔒", color = Color.White.copy(alpha = .75f), fontSize = 13.sp)
    }
}

@Composable
fun InboxScreen(email: String, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { Db.get(ctx).dao() }
    val items by dao.all().collectAsState(emptyList())
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    fun enabled() = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    var allowed by remember { mutableStateOf(enabled()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { allowed = enabled() }

    val tabs = listOf("All" to items.size, "Unread" to items.count { !it.read }, "Important" to items.count { it.important }, "Saved" to items.count { it.saved })
    val groups = items.filter {
        when (tab) { 1 -> !it.read; 2 -> it.important; 3 -> it.saved; else -> true } &&
            (query.isBlank() || (it.title + it.text + it.appName).contains(query, true))
    }.groupBy { it.pkg }.values.toList()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 40.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Calmify", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("$email · ${tabs[1].second} unread", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                FilledTonalIconButton(onClick = onSignOut) { Icon(Icons.AutoMirrored.Rounded.Logout, "Sign out") }
            }
        }
        if (!allowed) item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("নোটিফিকেশন অ্যাক্সেস দিন", fontWeight = FontWeight.Bold)
                    Text("অন্য অ্যাপের নোটিফিকেশন এখানে জমা করতে অনুমতি লাগবে।", fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text("অনুমতি দিন") }
                }
            }
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp), placeholder = { Text("Search…") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) }
            )
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tabs.forEachIndexed { i, (name, n) ->
                    FilterChip(selected = tab == i, onClick = { tab = i }, shape = RoundedCornerShape(18.dp), label = { Text("$name $n") })
                }
            }
        }
        if (groups.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(top = 60.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Inbox, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = .5f))
                Text("কিছু নেই", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
            }
        }
        items(groups, key = { it.first().pkg }) { g ->
            GroupCard(g, onUpdate = { n -> scope.launch { dao.update(n) } }, onDelete = { n -> scope.launch { dao.delete(n) } })
        }
    }
}

@Composable
fun GroupCard(list: List<Notif>, onUpdate: (Notif) -> Unit, onDelete: (Notif) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val first = list.first()
    val multi = list.size > 1
    Card(
        shape = RoundedCornerShape(26.dp), elevation = CardDefaults.cardElevation(3.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().clickable(enabled = multi) {
                    open = !open; if (open) list.filter { !it.read }.forEach { onUpdate(it.copy(read = true)) }
                }
            ) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(palette[abs(first.pkg.hashCode()) % palette.size]), contentAlignment = Alignment.Center) {
                    Text(first.appName.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(first.appName, fontWeight = FontWeight.SemiBold)
                    Text(DateUtils.getRelativeTimeSpanString(first.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
                }
                if (list.any { !it.read }) Box(Modifier.size(9.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                if (multi) { Spacer(Modifier.width(8.dp)); Text("${list.size}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null) }
            }
            if (!multi || open) list.forEach { Item(it, onUpdate, onDelete) }
            else Text(first.title.ifBlank { first.text }, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
        }
    }
}

@Composable
fun Item(n: Notif, onUpdate: (Notif) -> Unit, onDelete: (Notif) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.padding(top = 12.dp)) {
        if (n.title.isNotBlank()) Text(n.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (n.text.isNotBlank()) Text(n.text, maxLines = 3, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f), fontSize = 14.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            AssistChip(
                onClick = { ctx.packageManager.getLaunchIntentForPackage(n.pkg)?.let { ctx.startActivity(it) }; onUpdate(n.copy(read = true)) },
                label = { Text("Open") }, leadingIcon = { Icon(Icons.AutoMirrored.Rounded.OpenInNew, null, Modifier.size(16.dp)) }
            )
            IconButton(onClick = { onUpdate(n.copy(important = !n.important)) }) {
                Icon(if (n.important) Icons.Rounded.Star else Icons.Rounded.StarBorder, "Important", tint = if (n.important) Color(0xFFF59E0B) else Color.Gray)
            }
            IconButton(onClick = { onUpdate(n.copy(saved = !n.saved)) }) {
                Icon(if (n.saved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder, "Save", tint = if (n.saved) MaterialTheme.colorScheme.primary else Color.Gray)
            }
            IconButton(onClick = { onDelete(n) }) { Icon(Icons.Rounded.DeleteOutline, "Delete", tint = Color.Gray) }
        }
    }
}
