package com.likhon.calmify

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.format.DateUtils
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

val Blue = Color(0xFF2563EB)
val palette = listOf(Blue, Color(0xFFE11D48), Color(0xFF059669), Color(0xFFD97706), Color(0xFF7C3AED), Color(0xFF0891B2))

@Composable
fun HubTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF7AA2FF), onPrimary = Color(0xFF0B1020), primaryContainer = Color(0xFF23304F), onPrimaryContainer = Color(0xFFDCE6FF),
        background = Color(0xFF0E1320), onBackground = Color(0xFFE6EAF5), surface = Color(0xFF181F30), onSurface = Color(0xFFE6EAF5),
        surfaceVariant = Color(0xFF232B3F), onSurfaceVariant = Color(0xFFB4BCD0), outline = Color(0xFF3A4560),
        errorContainer = Color(0xFF4A2530), onErrorContainer = Color(0xFFFFDADF)
    ) else lightColorScheme(
        primary = Blue, onPrimary = Color.White, primaryContainer = Color(0xFFE3ECFF), onPrimaryContainer = Color(0xFF0B2A6B),
        background = Color(0xFFF3F6FC), onBackground = Color(0xFF111827), surface = Color.White, onSurface = Color(0xFF111827),
        surfaceVariant = Color(0xFFEAEFF9), onSurfaceVariant = Color(0xFF475569), outline = Color(0xFFCBD5E1),
        errorContainer = Color(0xFFFFE4E8), onErrorContainer = Color(0xFF7A1226)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun LoginScreen(error: String?, lang: String, onLang: (String) -> Unit, onSignIn: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1E3A8A), Color(0xFF2563EB), Color(0xFF60A5FA)))).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { onLang(if (lang == "en") "bn" else "en") }) { Text(if (lang == "en") "বাংলা" else "English", color = Color.White) }
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(96.dp).clip(RoundedCornerShape(32.dp)).background(Color.White.copy(alpha = .2f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.NotificationsActive, null, tint = Color.White, modifier = Modifier.size(52.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Calmify", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Text(tr("tagline"), color = Color.White.copy(alpha = .85f), fontSize = 16.sp)
        Spacer(Modifier.height(48.dp))
        Button(
            onClick = onSignIn, shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Icon(Icons.Rounded.Email, null, tint = Color(0xFFEA4335)); Spacer(Modifier.width(10.dp))
            Text(tr("signin"), fontWeight = FontWeight.SemiBold)
        }
        error?.let { Spacer(Modifier.height(16.dp)); Text("${tr("login_error")}: $it", color = Color(0xFFFFE4E6), fontSize = 13.sp) }
        Spacer(Modifier.weight(1f))
        Text("🔒 ${tr("privacy")}", color = Color.White.copy(alpha = .75f), fontSize = 13.sp)
    }
}

@Composable
fun MainScreen(email: String, theme: String, onTheme: (String) -> Unit, lang: String, onLang: (String) -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { Db.get(ctx).dao() }
    val items by dao.all().collectAsState(emptyList())
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val tabs = listOf("inbox" to Icons.Rounded.Inbox, "apps" to Icons.Rounded.Apps, "insights" to Icons.Rounded.BarChart, "settings" to Icons.Rounded.Settings)
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, (k, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, null) }, label = { Text(tr(k), fontSize = 11.sp) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> InboxScreen(items, { n -> scope.launch { dao.update(n) } }, { n -> scope.launch { dao.delete(n) } }, { scope.launch { dao.markAllRead() } })
                1 -> AppsScreen()
                2 -> InsightsScreen(items)
                else -> SettingsScreen(email, theme, onTheme, lang, onLang, { scope.launch { dao.clearUnsaved() } }, onSignOut)
            }
        }
    }
}

@Composable
fun InboxScreen(items: List<Notif>, onUpdate: (Notif) -> Unit, onDelete: (Notif) -> Unit, onMarkAll: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var cat by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    fun enabled() = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    var allowed by remember { mutableStateOf(enabled()) }
    fun rebind() { try { NotificationListenerService.requestRebind(ComponentName(ctx, HubListener::class.java)) } catch (_: Exception) {} }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { allowed = enabled(); if (allowed) rebind() }
    var connected by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { connected = ctx.getSharedPreferences("hub", 0).getBoolean("connected", false); delay(1500) } }

    val tabs = listOf("all" to items.size, "unread" to items.count { !it.read }, "important" to items.count { it.important }, "saved" to items.count { it.saved })
    val cats = listOf("all", "c_social", "c_messages", "c_email", "c_shopping", "c_finance", "c_other")
    val groups = items.filter {
        when (tab) { 1 -> !it.read; 2 -> it.important; 3 -> it.saved; else -> true } &&
            (cat == 0 || categoryOf(it.pkg) == cats[cat]) &&
            (query.isBlank() || (it.title + it.text + it.appName).contains(query, true))
    }.groupBy { it.pkg }.values.toList()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("inbox"), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("${items.size} ${tr("notifications")} · ${tabs[1].second} ${tr("unread")}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalIconButton(onClick = onMarkAll) { Icon(Icons.Rounded.DoneAll, tr("mark_read")) }
            }
        }
        if (!allowed) item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text(tr("grant_title"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(tr("grant_body"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text(tr("grant_btn")) }
                }
            }
        } else if (connected) item {
            Text("● ${tr("connected")}", color = Color(0xFF10B981), fontSize = 12.sp)
        } else item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text(tr("not_connected"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { rebind() }) { Text(tr("fix_btn")) }
                        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))) }) { Text(tr("battery")) }
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp), placeholder = { Text(tr("search")) },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, null) } },
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = MaterialTheme.colorScheme.outline, unfocusedContainerColor = MaterialTheme.colorScheme.surface, focusedContainerColor = MaterialTheme.colorScheme.surface)
            )
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tabs.forEachIndexed { i, (k, n) ->
                    FilterChip(selected = tab == i, onClick = { tab = i }, shape = RoundedCornerShape(18.dp), label = { Text("${tr(k)} $n") })
                }
            }
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.forEachIndexed { i, k ->
                    AssistChip(
                        onClick = { cat = i }, shape = RoundedCornerShape(18.dp), label = { Text(tr(if (i == 0) "all" else k), fontSize = 12.sp) },
                        colors = AssistChipDefaults.assistChipColors(containerColor = if (cat == i) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                    )
                }
            }
        }
        if (groups.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(top = 56.dp, start = 24.dp, end = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Inbox, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = .45f))
                Spacer(Modifier.height(8.dp))
                Text(tr("nothing"), fontWeight = FontWeight.SemiBold)
                Text(tr("empty_hint"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(groups, key = { it.first().pkg }) { g -> GroupCard(g, onUpdate, onDelete) }
    }
}

@Composable
fun GroupCard(list: List<Notif>, onUpdate: (Notif) -> Unit, onDelete: (Notif) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val first = list.first()
    val multi = list.size > 1
    Card(
        shape = RoundedCornerShape(26.dp), elevation = CardDefaults.cardElevation(2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().clickable(enabled = multi) {
                    open = !open; if (open) list.filter { !it.read }.forEach { onUpdate(it.copy(read = true)) }
                }
            ) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(palette[abs(first.pkg.hashCode()) % palette.size]), contentAlignment = Alignment.Center) {
                    Text(first.appName.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(first.appName, fontWeight = FontWeight.SemiBold)
                    Text(DateUtils.getRelativeTimeSpanString(first.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (list.any { !it.read }) Box(Modifier.size(9.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                if (multi) { Spacer(Modifier.width(8.dp)); Text("${list.size}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null) }
            }
            if (!multi || open) list.forEach { NotifItem(it, onUpdate, onDelete) }
            else Text(first.title.ifBlank { first.text }, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 10.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun NotifItem(n: Notif, onUpdate: (Notif) -> Unit, onDelete: (Notif) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.padding(top = 12.dp)) {
        if (n.title.isNotBlank()) Text(n.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (n.text.isNotBlank()) Text(n.text, maxLines = 3, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            AssistChip(
                onClick = { ctx.packageManager.getLaunchIntentForPackage(n.pkg)?.let { ctx.startActivity(it) }; onUpdate(n.copy(read = true)) },
                label = { Text(tr("open")) }, leadingIcon = { Icon(Icons.AutoMirrored.Rounded.OpenInNew, null, Modifier.size(16.dp)) }
            )
            IconButton(onClick = { onUpdate(n.copy(important = !n.important)) }) {
                Icon(if (n.important) Icons.Rounded.Star else Icons.Rounded.StarBorder, tr("important"), tint = if (n.important) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { onUpdate(n.copy(saved = !n.saved)) }) {
                Icon(if (n.saved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder, tr("saved"), tint = if (n.saved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { onDelete(n) }) { Icon(Icons.Rounded.DeleteOutline, tr("delete"), tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
